
public class Marco
{
    private int _posXv1;
    private int _posYv1;
    private int _posXv2;
    private int _posYv2;
    private int _ancho;
    private int _alto;
    private int _contaLinea;
    private int _nlineas = 1;
    private ConsoleColor _colorFondo;
    private ConsoleColor _colorBorde;

    public Marco(int xv1, int yv1, int xv2, int yv2, int nlin, ConsoleColor colFond, ConsoleColor colBor)
    {
        _posXv1 = xv1;
        _posXv2 = xv2;
        _posYv1 = yv1;
        _posYv2 = yv2;
        _ancho = _posXv2 - _posXv1;
        _alto = _posYv2 - _posYv1;
        _nlineas = (_nlineas != 1 && _nlineas != 2)? _nlineas : 2;
        _colorFondo = colFond;
        _colorBorde = colBor;
    }
    
    public void DibujarMarco()
    {
        Console.BackgroundColor = _colorFondo;
        Console.ForegroundColor = _colorBorde;
        char pared = ' ';
        char suelo = ' ';
        char EsqArrDer = ' ';
        char EsqArrIzq = ' ';
        char EsqAbaDer = ' ';
        char EsqAbaIzq = ' ';
        char MedIzq = ' ';
        char MedDer = ' ';
        
        if (_nlineas == 2)
        {
            pared = '║';
            suelo = '═';
            EsqArrDer = '╝';
            EsqArrIzq = '╚';
            EsqAbaDer = '╗';
            EsqAbaIzq = '╔';
            MedIzq = '╠';
            MedDer = '╣';
        }
        else if (_nlineas == 1)
        {
            pared = '┃';
            suelo = '━';
            EsqArrDer = '┛';
            EsqArrIzq = '┗';
            EsqAbaDer = '┓';
            EsqAbaIzq = '┏';
            MedIzq = '┣';
            MedDer = '┫';
        }

        int _contaLinea = _posYv1;
        int maxAncho = Console.WindowWidth -2;
        int maxAlto = Console.WindowHeight -2;
        
        // Controlar dimensiones
        if (_ancho > maxAncho)
        {_ancho = maxAncho;}
        if (_alto > maxAlto)
        {_alto = maxAlto;}


        // Dibujar marco
        DrawTecho(suelo, EsqAbaIzq, EsqAbaDer);
        DrawLine(pared);
        DrawSeparator(suelo, MedIzq, MedDer);
        for (int i = 1; i < _alto - 4; i++)
        {DrawLine(pared);}
        DrawSeparator(suelo, MedIzq, MedDer);
        DrawLine(pared);
        DrawSuelo(suelo, EsqArrIzq, EsqArrDer);
    }
    
    public void DrawSeparator(char suelo, char MedIzq, char MedDer)
    {
        Console.SetCursorPosition(_posXv1, _contaLinea++);
        Console.Write(MedIzq);
        for (int i = 0; i < _ancho; i++)
        {Console.Write(suelo);}
        Console.Write(MedDer+"\n");
    }
    public void DrawSuelo(char suelo, char EsqArrIzq, char EsqArrDer)
    {
        Console.SetCursorPosition(_posXv1, _contaLinea++);
        Console.Write(EsqArrIzq);
        for (int i = 0; i < _ancho; i++)
        {Console.Write(suelo);}
        Console.Write(EsqArrDer+"\n");
    }
    public void DrawTecho(char suelo, char EsqAbaIaq, char EsqAbaDer)
    {
        Console.SetCursorPosition(_posXv1, _contaLinea++);
        Console.Write(EsqAbaIaq);
        for (int i = 0; i < _ancho; i++)
        {Console.Write(suelo);}
        Console.Write(EsqAbaDer+"\n");
    }
    public void DrawLine(char pared)
    {
        Console.SetCursorPosition(_posXv1, _contaLinea++);
        Console.Write(pared);
        for (int i = 0; i < _ancho; i++)
        {Console.Write(" ");}
        Console.Write(pared+"\n");
    }
}