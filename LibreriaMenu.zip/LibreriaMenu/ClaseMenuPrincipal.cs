﻿using System.Dynamic;
using System.Formats.Asn1;
using System.Globalization;
using System.Runtime.CompilerServices;

public class MenuPrincipal
{
    private string _titulo;
    private string _mensaje;
    private string[] _opciones;
    private ConsoleColor _colorLetra;
    
    public string Mensaje { get => _mensaje; set => _mensaje = value; }
    public string Titulo { get => _titulo; set => _titulo = value; }
    public string[] Opciones { get => _opciones; set => _opciones = value; }


    public MenuPrincipal(string titulo, string mensaje, string[] opciones)
    {
        _titulo = titulo;
        _mensaje = mensaje;
        _opciones = opciones;
    }

    public void MostrarMenu(int posXv1, int posYv1, int posXv2, int posYv2, int nlin, ConsoleColor colorFondo, ConsoleColor colorLetra,  ConsoleColor colorBorde)
    {
        Console.Clear();
        _colorLetra = colorLetra;
        int tituloCentrado = (((posXv2)/2)-(_titulo.Length/2) + 1);
        var marco = new Marco(posXv1, posYv1, posXv2, posYv2, nlin, colorFondo, colorBorde);
        marco.DibujarMarco();
        Console.ForegroundColor = colorLetra;
        Console.SetCursorPosition(tituloCentrado, posYv1);
        Console.Write($" {_titulo} ");
        
        Console.SetCursorPosition(posXv1 + 2, posYv1 + 3);

        for (int i = 0; i < _opciones.Length; i++)
        {
            Console.SetCursorPosition(posXv1 + 2, posYv1 + i * 2 + 3);
            Console.Write($" {i + 1}. {_opciones[i]}");
        }

        Console.SetCursorPosition(posXv1 + 2, posYv2-2);
        Console.Write($" {_mensaje} ");

        Console.SetCursorPosition(32, 32);
        Console.BackgroundColor = ConsoleColor.Black;
        Console.ForegroundColor = ConsoleColor.White;
        Thread.Sleep(3000);
    }
    public void ModificacionOpciones(string[] opciones)
    {_opciones = opciones;}
    public void ModificacionMensaje(string mensaje)
    {_mensaje = mensaje;}
    public void ModificacionTitulo(string titulo)
    {_titulo = titulo;}
}
